Hello,

Thank you for purchasing

- How to Enable OpenType Features in Word, Photoshop and Illustrator
  https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

- How to Using Special Characters
  https://helpx.adobe.com/illustrator/using/special-characters.html


Note of the author

This font DEMO free for PERSONAL USE only

By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: 
https://fontbundles.net/twiri/1308164-osnabrug-font-quirky-handwritten

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
Twinrizki08@gmail.com

- Any donation are very appreciated. Paypal account for donation : 
paypal.me/Elawulansari
-------------------

INDONESIA:

Hi desainer

font demo ini gratis hanya untuk keperluan PRIBADI

Dilarang keras menggunakan font untuk kepentingan komersial/ alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, iklan tv, iklan social media, iklan marketplace, Agensi Desain Grafis, Percetakan, Perusahaan

Silakan gunakan lisensi komersial dengan membeli melalui link ini :
https://fontbundles.net/twiri/1308164-osnabrug-font-quirky-handwritten

Terimakasih